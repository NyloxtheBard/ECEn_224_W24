#!/bin/bash

echo "Yay! You got me working!"
echo " "
echo "Task 4 (of 7): Create a new file called solution.txt and write down the command that allows you to change the permissions of a file. Then go to the scripts directory and run the script contained there."
