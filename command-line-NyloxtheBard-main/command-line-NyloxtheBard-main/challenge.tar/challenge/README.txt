Welcome to the Shell Challenge!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is a quick challenge which will test your knowledge of getting around the terminal. To complete this challenge you will need to follow the prompts at each level and complete each task.

Task 1 (of 7): Change your current directory into the the mov directory. Then read the file contained there. 
